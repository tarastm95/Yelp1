# Frontend

This frontend now uses **Vite** as the build tool instead of Create React App.

## Available Scripts

- `npm run dev` - start the development server
- `npm run build` - build the app for production
- `npm run preview` - locally preview the production build
- `npm test` - run tests with react-scripts
